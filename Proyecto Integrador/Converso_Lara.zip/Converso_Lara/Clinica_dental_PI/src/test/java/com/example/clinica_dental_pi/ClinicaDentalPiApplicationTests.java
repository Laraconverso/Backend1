package com.example.clinica_dental_pi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaDentalPiApplicationTests {

    @Test
    void contextLoads() {
    }

}
