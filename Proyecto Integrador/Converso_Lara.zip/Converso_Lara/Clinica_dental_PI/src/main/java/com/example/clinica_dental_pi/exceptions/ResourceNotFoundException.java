package com.example.clinica_dental_pi.exceptions;

public class ResourceNotFoundException extends Exception{

    public ResourceNotFoundException(String m) {
        super(m);
    }
}
