package com.example.clinica_dental_pi.model;

public enum UsuarioRol {
    USER, ADMIN
}
