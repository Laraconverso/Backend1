package com.example.clinica_dental_pi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaDentalPiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClinicaDentalPiApplication.class, args);
    }

}
