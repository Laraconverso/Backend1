package com.example.clinicadental.serviceTest;

import com.example.clinicadental.clinica.dao.impl.DomicilioDaoH2;
import com.example.clinicadental.clinica.dao.impl.OdontologoDaoH2;
import com.example.clinicadental.clinica.dao.impl.PacienteDaoH2;
import com.example.clinicadental.clinica.dao.impl.TurnoDaoRepository;
import com.example.clinicadental.clinica.model.Domicilio;
import com.example.clinicadental.clinica.model.Odontologo;
import com.example.clinicadental.clinica.model.Paciente;
import com.example.clinicadental.clinica.model.Turno;
import com.example.clinicadental.clinica.service.DomicilioService;
import com.example.clinicadental.clinica.service.OdontologoService;
import com.example.clinicadental.clinica.service.PacienteService;
import com.example.clinicadental.clinica.service.TurnoService;
import org.junit.Assert;
import org.junit.Test;

import java.util.Date;

public class TurnoServiceTest {
    TurnoService turnoService = new TurnoService(new TurnoDaoRepository());
    OdontologoService odontologoService = new OdontologoService(new OdontologoDaoH2());
    PacienteService pacienteService = new PacienteService(new PacienteDaoH2());


    @Test
    public void agregarYBuscarTurnosTest() {
        System.out.println("==============================");
        System.out.println("TEST AGREGAR Y BUSCAR TURNOS");
        System.out.println("==============================");
        Domicilio domicilio = new Domicilio("Calle", "123", "Temperley", "Buenos Aires");
        Paciente paciente = pacienteService.guardar(new Paciente("Tomas", "Pereyra", "12345678", new Date(), domicilio));
        Odontologo odontologo = odontologoService.guardar(new Odontologo("001", "Martin", "Rodriguez"));
        Turno turno = turnoService.guardar(new Turno(1,paciente,odontologo,new Date()));

        Assert.assertNotNull(turnoService.buscar(turno.getId()));
        //turnoService.eliminar(turno.getId());
    }

    @Test
    public void eliminarOdontologoTest() {
        System.out.println("==============================");
        System.out.println("TEST ELIMINAR TURNO");
        System.out.println("==============================");
        Domicilio domicilio = new Domicilio("Calle", "123", "Temperley", "Buenos Aires");
        Paciente paciente = pacienteService.guardar(new Paciente("Tomas", "Pereyra", "12345678", new Date(), domicilio));
        Odontologo odontologo = odontologoService.guardar(new Odontologo("001", "Martin", "Rodriguez"));
        Turno turno = turnoService.guardar(new Turno(2,paciente,odontologo,new Date()));

        turnoService.eliminar(turno.getId());
        Assert.assertTrue(turnoService.buscar(turno.getId()) == null);

    }

    @Test
    public void buscarTodosOdontologoTest() {
        System.out.println("==============================");
        System.out.println("TEST BUSCAR TODOS LOS TURNOS");
        System.out.println("==============================");
        Odontologo odontologo1 = new Odontologo("003", "Nicolas", "Avigliano");
        Odontologo odontologo2 = new Odontologo("004", "Violeta", "Matorras");
        Domicilio domicilio1 = new Domicilio("Av Santa fe", "444", "CABA", "Buenos Aires");
        Paciente paciente1 = pacienteService.guardar(new Paciente("Santiago", "Paz", "88888888", new Date(), domicilio1));
        Domicilio domicilio2 = new Domicilio("Calle", "123", "Temperley", "Buenos Aires");
        Paciente paciente2 = pacienteService.guardar(new Paciente("Tomas", "Pereyra", "12345678", new Date(), domicilio2));

        Turno turno1 = new Turno(3,paciente1,odontologo1,new Date());
        Turno turno2 = new Turno(4, paciente2,odontologo2, new Date());

        turnoService.guardar(turno1);
        turnoService.guardar(turno2);

        int tamanio = turnoService.buscarTodos().size();
        Assert.assertEquals(tamanio, turnoService.buscarTodos().size());

        turnoService.eliminar(turno1.getId());
        turnoService.eliminar(turno2.getId());
    }
}
