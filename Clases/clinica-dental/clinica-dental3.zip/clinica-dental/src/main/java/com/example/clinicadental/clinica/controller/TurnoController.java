package com.example.clinicadental.clinica.controller;

import com.example.clinicadental.clinica.dao.impl.OdontologoDaoH2;
import com.example.clinicadental.clinica.dao.impl.PacienteDaoH2;
import com.example.clinicadental.clinica.dao.impl.TurnoDaoRepository;
import com.example.clinicadental.clinica.model.Odontologo;
import com.example.clinicadental.clinica.model.Paciente;
import com.example.clinicadental.clinica.model.Turno;
import com.example.clinicadental.clinica.service.OdontologoService;
import com.example.clinicadental.clinica.service.PacienteService;
import com.example.clinicadental.clinica.service.TurnoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/turnos")
public class TurnoController {

    private TurnoService turnoService = new TurnoService(new TurnoDaoRepository());

    @GetMapping("/{id}")
    public ResponseEntity<Turno> buscar(@PathVariable Integer id){
        Turno turno = turnoService.buscar(id);
        if(turno !=null){
            return ResponseEntity.ok(turno);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable Integer id){
        ResponseEntity<String> response;
        if (turnoService.buscar(id) != null){
            turnoService.eliminar(id);
            response = ResponseEntity.status(HttpStatus.OK).body("Eliminado");
        }else{
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return response;

    }

    @PutMapping
    public ResponseEntity<Turno> actulizar(@RequestBody Turno turno){
        return ResponseEntity.ok(turnoService.actualizar(turno));
    }

    @GetMapping
    public ResponseEntity<List<Turno>> buscarTodos(){
        return ResponseEntity.ok(turnoService.buscarTodos());
    }

    //esto esta mal revisar
    @PostMapping
    public ResponseEntity<Turno> guardar(@RequestBody Turno turno){
        return ResponseEntity.ok(turnoService.guardar(turno));
        /*if(turno.getPaciente() != null && turno.getOdontologo() != null){
            return ResponseEntity.ok(turnoService.guardar(turno));
        }else{
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }*/
    }

}

 /*   Dar de alta nuevos turnos, previamente validar que el paciente y el odontólogo existen en el sistema.
        Para este punto retorna un código de status 400(BAD REQUEST) en caso de que no existan el paciente o el odontólogo.
        En caso de registrar correctamente el turno, retornar 200.
        PATH: /turnos METODO: POST
        Listar todos los turnos.
        PATH:/turnos METODO : GET
        Eliminar turnos.
        PATH :/turnos/{id} METODO: DELETE
        Actualizar turnos.
        PATH: /turnos METODO: PUT

        Para esta etapa final, te solicitan probar estos cuatro endpoints utilizando postman.
        A su vez, debés comprobar fundamentalmente los posibles casos de errores, como agregar un turno a un odontólogo que no existe en la base de datos, o eliminar un turno que no exista en la base de datos.

*/
