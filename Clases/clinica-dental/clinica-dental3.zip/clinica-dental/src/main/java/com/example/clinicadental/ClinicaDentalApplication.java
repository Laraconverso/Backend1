package com.example.clinicadental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaDentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaDentalApplication.class, args);
	}

}
